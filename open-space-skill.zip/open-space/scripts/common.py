"""Shared helpers for the open-space scripts: the site in metres, reading layers, the style, PNG export."""
import json
import math
import os
import shutil
import subprocess
from pathlib import Path

import numpy as np
import shapely
from pyproj import CRS, Transformer
from shapely.geometry import mapping, shape


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")


class Site:
    """The project's site folder, worked on in the UTM zone of the site (metres)."""

    def __init__(self, folder):
        self.dir = Path(folder)
        self.poly_ll = shape(read(self.dir / "site.geojson")["features"][0]["geometry"])
        c = self.poly_ll.centroid
        zone = int((c.x + 180) // 6) + 1
        self.crs = CRS.from_epsg((32600 if c.y >= 0 else 32700) + zone)
        self._fw = Transformer.from_crs(4326, self.crs, always_xy=True)
        self._bw = Transformer.from_crs(self.crs, 4326, always_xy=True)
        self.poly = self.to_m(self.poly_ll)

    def to_m(self, g):
        return shapely.transform(g, lambda xy: np.column_stack(self._fw.transform(xy[:, 0], xy[:, 1])))

    def to_ll(self, g):
        return shapely.transform(g, lambda xy: np.round(np.column_stack(self._bw.transform(xy[:, 0], xy[:, 1])), 7))

    def layer(self, path):
        """Features of a GeoJSON file as (geometry in metres, properties); [] if the file is missing."""
        p = Path(path)
        if not p.exists():
            return []
        out = []
        for f in read(p).get("features", []):
            if f.get("geometry"):
                g = self.to_m(shape(f["geometry"]))
                if not g.is_valid:
                    g = shapely.make_valid(g)
                out.append((g, f.get("properties") or {}))
        return out

    def site_layer(self, name):
        return self.layer(self.dir / f"{name}.geojson")

    def write_geojson(self, path, feats):
        """feats: list of (geometry in metres, properties). Written in WGS84, longitude first."""
        out = [{"type": "Feature", "geometry": mapping(self.to_ll(g)), "properties": p}
               for g, p in feats if g is not None and not g.is_empty]
        write_json(path, {"type": "FeatureCollection", "features": out})


def polys(g):
    """Only the polygonal part of a geometry (intersections can leave lines and points)."""
    if g is None or g.is_empty:
        return shapely.Polygon()
    if g.geom_type in ("Polygon", "MultiPolygon"):
        return g
    parts = [p for p in getattr(g, "geoms", []) if p.geom_type in ("Polygon", "MultiPolygon")]
    return shapely.union_all(parts) if parts else shapely.Polygon()


def union(gs):
    gs = [g for g in gs if g is not None and not g.is_empty]
    return shapely.union_all(gs) if gs else shapely.Polygon()


# ---------- drawing: style and PNG ----------

FALLBACK = dict(paper="#ffffff", ink="#000000", accent="#2e7d4f", context="#c9c9c9", water=None,
                font="Helvetica, Arial, sans-serif", thin=0.1, mid=0.25, thick=0.6, text=2.4, title=5.0)


def style(path):
    """The drawing standard as a dict; keys missing from style.json fall back to black on white with one accent."""
    st = dict(FALLBACK, **(read(path) if path else {}))
    st["from_standard"] = bool(path)
    return st


def hex2rgb(h):
    h = h.lstrip("#")
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def mix(a, b, t):
    a, b = hex2rgb(a), hex2rgb(b)
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(a, b))


def browser():
    cands = [os.environ.get("BROWSER"), shutil.which("chrome"), shutil.which("google-chrome"), shutil.which("chromium"),
             shutil.which("chromium-browser"), shutil.which("msedge"), shutil.which("microsoft-edge"),
             r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
             r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
             "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    return next((c for c in cands if c and Path(c).exists()), None)


def png(svg, w_mm, h_mm, scale=2):
    """PNG next to the SVG, by a headless Chrome or Edge; cairosvg if no browser is found. Returns how, or None."""
    svg, out = Path(svg).resolve(), Path(svg).with_suffix(".png").resolve()
    exe = browser()
    if exe:
        px = lambda mm: math.ceil(mm * 96 / 25.4)
        cmd = [exe, "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--force-device-scale-factor={scale}",
               f"--window-size={px(w_mm)},{px(h_mm)}", f"--screenshot={out}", svg.as_uri()]
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(1, "--no-sandbox")
        subprocess.run(cmd, capture_output=True, timeout=180)
        if out.exists():
            return "browser"
    try:
        import cairosvg
        cairosvg.svg2png(url=str(svg), write_to=str(out), output_width=math.ceil(w_mm * 96 / 25.4 * scale))
        return "cairosvg"
    except Exception:
        return None
