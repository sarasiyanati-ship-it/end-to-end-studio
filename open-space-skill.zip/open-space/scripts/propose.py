"""Propose the open spaces of a design: parks, squares, green corridors, playgrounds, rainwater retention and trees.

python propose.py --site SITE_DIR --proposal PROPOSAL_DIR [--targets targets.json] [--out PROPOSAL_DIR/open-space]

Reads, each only if it is there:
  PROPOSAL/structure-plan/structure-plan.geojson  neighbourhood, centre, green (roles), route (level), gateway
                                                  without it: a simple stand-in from the site, said so in every output
  PROPOSAL/massing/massing.geojson                building footprints and streets, for the sealed area
  PROPOSAL/climate/fresh-air.geojson, sun-hours.geojson, radiation.geojson, rules.geojson
  SITE/plots.geojson, SITE/water.geojson          existing green and water inside the site
targets.json: the brief's numbers, each {"value": ..., "source": "brief p. N"}; every key left out uses DEFAULTS below,
named as an assumption in assumptions.md. Keys: see DEFAULTS.
Writes into OUT: open-space.geojson, catchments.geojson, key-numbers.json, key-numbers.csv, assumptions.md, summary.md.
"""
import argparse
import csv
import math
from pathlib import Path

import numpy as np
import shapely
from shapely import affinity
from shapely.geometry import LineString, Point, box
from shapely.ops import nearest_points

from common import Site, polys, read, union, write_json

A = "assumption"
DEFAULTS = {
    # from the brief; no default, the step that needs them is skipped and named
    "residents": None,
    "public_green_m2_per_resident": None,
    "play_m2_per_resident": None,
    "play_min_m2": None,
    # design rain: replace with the local design rain statistics (in Germany KOSTRA-DWD) for the return period the city asks for
    "design_rain_mm": (30, f"{A}: design rain of 30 mm in 60 min, held without outflow; replace with the local design rain"),
    "design_rain_duration_min": (60, f"{A}: duration of the design rain"),
    "throttle_l_s_ha": (0, f"{A}: no outflow during the rain (the safe side); use the allowed discharge if the city sets one"),
    "runoff_roof": (0.9, f"{A}: typical mean runoff coefficient, pitched or flat roof"),
    "runoff_green_roof": (0.5, f"{A}: typical mean runoff coefficient, extensive green roof"),
    "green_roof_share": (0.0, f"{A}: share of roofs built as green roofs"),
    "runoff_road": (0.9, f"{A}: typical mean runoff coefficient, asphalt"),
    "runoff_square": (0.6, f"{A}: typical mean runoff coefficient, paving with open joints"),
    "roof_share": (0.35, f"{A}: roofs as share of a neighbourhood's land, used only without massing"),
    "road_share": (0.15, f"{A}: streets and paths as share of a neighbourhood's land, used only without massing"),
    "swale_depth_m": (0.3, f"{A}: swale water depth (shallow swales drain within a day)"),
    "basin_depth_m": (1.0, f"{A}: retention basin water depth"),
    "slope_factor": (1.3, f"{A}: land per m2 of water surface, for banks and freeboard"),
    "swale_width_m": (8, f"{A}: width of a swale strip along a neighbourhood's green edge"),
    "reach_m": (300, f"{A}: every home within 300 m of a public green of at least 0.5 ha (WHO Europe, 2016)"),
    "pocket_park_m2": (5000, f"{A}: smallest new neighbourhood park, 0.5 ha (WHO Europe, 2016)"),
    "square_main_m2": (4000, f"{A}: square at a main centre"),
    "square_local_m2": (1500, f"{A}: square at a local centre"),
    "tree_spacing_m": (12, f"{A}: tree spacing along routes"),
    "square_tree_grid_m": (10, f"{A}: tree grid in squares"),
}
KEEP_GREEN = {"forest", "natural:wood", "natural:scrub", "natural:wetland", "natural:heath", "natural:grassland",
              "leisure:park", "leisure:nature_reserve", "wood", "orchard", "meadow_orchard", "allotments"}


def targets(path):
    raw = read(path) if path and Path(path).exists() else {}
    T, used = {}, []
    for k, d in DEFAULTS.items():
        if k in raw and raw[k] is not None:
            v = raw[k]
            T[k] = (v["value"], v.get("source", "targets.json")) if isinstance(v, dict) else (v, "targets.json")
        elif d is not None:
            T[k] = d
            used.append(k)
        else:
            T[k] = (None, "not in targets.json")
    return T, used


def roles_of(p):
    r = p.get("roles") or []
    return [r] if isinstance(r, str) else list(r)


def elongated(g, ratio=3.0):
    r = g.minimum_rotated_rectangle
    if r.geom_type != "Polygon":
        return False
    xy = np.array(r.exterior.coords)
    a, b = np.hypot(*(xy[1] - xy[0])), np.hypot(*(xy[2] - xy[1]))
    return max(a, b) / max(min(a, b), 1) > ratio or g.area / max(r.area, 1) < 0.35


def grid_points(g, cell):
    if g.is_empty:
        return []
    x0, y0, x1, y1 = g.bounds
    xs, ys = np.meshgrid(np.arange(x0 + cell / 2, x1, cell), np.arange(y0 + cell / 2, y1, cell))
    pts = shapely.points(xs.ravel(), ys.ravel())
    return list(pts[shapely.contains(g, pts)])


def grow(region, anchor, target_area, rmax=2000):
    """The part of region within a circle round anchor whose area is about target_area (whole region if smaller)."""
    if region.area <= target_area:
        return region
    lo, hi = 0.0, rmax
    for _ in range(30):
        mid = (lo + hi) / 2
        if region.intersection(anchor.buffer(mid, 24)).area < target_area:
            lo = mid
        else:
            hi = mid
    return polys(region.intersection(anchor.buffer(hi, 24)))


def oriented_box(center, area, angle_deg, aspect=1.5):
    w, h = math.sqrt(area * aspect), math.sqrt(area / aspect)
    b = box(center.x - w / 2, center.y - h / 2, center.x + w / 2, center.y + h / 2)
    return affinity.rotate(b, angle_deg, origin=center)


def line_angle(line, near):
    """Direction in degrees of the segment of line nearest to a point."""
    coords = list(line.coords)
    best, ang = 1e18, 0
    for a, b in zip(coords[:-1], coords[1:]):
        s = LineString([a, b])
        d = s.distance(near)
        if d < best:
            best, ang = d, math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))
    return ang


def standin_structure(S, kept):
    """A simple stand-in when no structure plan exists: the site split in four along its main axes,
    a 40 m green cross on the axes, a centre where they meet. Only to test; named as a stand-in everywhere."""
    site = S.poly
    r = site.minimum_rotated_rectangle
    xy = np.array(r.exterior.coords)[:4]
    e1, e2 = xy[1] - xy[0], xy[2] - xy[1]
    c = site.centroid
    L = max(np.hypot(*e1), np.hypot(*e2)) * 2
    axes = [LineString([(c.x - u[0] * L, c.y - u[1] * L), (c.x + u[0] * L, c.y + u[1] * L)])
            for u in (e1 / np.hypot(*e1), e2 / np.hypot(*e2))]
    cross = union([a.buffer(20) for a in axes]).intersection(site)
    centre = c.buffer(60).intersection(site)
    rest = site.difference(cross).difference(centre).difference(kept)
    tag = dict(basis="hypothesis", source="stand-in made by open-space: no structure plan found")
    out = [(g, dict(kind="neighbourhood", name=f"Quarter {i + 1}", action="new", **tag))
           for i, g in enumerate(sorted([p for p in getattr(rest, "geoms", [rest]) if p.area > 5000], key=lambda p: (-p.centroid.y, p.centroid.x)))]
    out.append((cross, dict(kind="green", name="Green cross", roles=["recreation", "climate", "water"], action="new", **tag)))
    out.append((centre, dict(kind="centre", name="Centre", level="main", action="new", **tag)))
    out += [(a.intersection(site), dict(kind="route", name=f"Axis {i + 1}", level="main", action="new", **tag)) for i, a in enumerate(axes)]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", required=True)
    ap.add_argument("--proposal", required=True)
    ap.add_argument("--targets")
    ap.add_argument("--out")
    a = ap.parse_args()
    S, P = Site(a.site), Path(a.proposal)
    out = Path(a.out or P / "open-space")
    out.mkdir(parents=True, exist_ok=True)
    T, defaulted = targets(a.targets or out / "targets.json")
    v = lambda k: T[k][0]
    site = S.poly
    notes, sources = [], []

    # ---------- inputs ----------
    kept_existing = []
    for g, p in S.site_layer("plots"):
        lu = str(p.get("landuse", ""))
        if lu in KEEP_GREEN or lu.split(":")[-1] in KEEP_GREEN:
            g = polys(g.intersection(site))
            if g.area > 200:
                kept_existing.append((g, lu, p.get("name")))
    water_existing = [polys(g.intersection(site)) for g, p in S.site_layer("water")]
    water_existing = [g for g in water_existing if g.area > 50]
    kept_u = union([g for g, _, _ in kept_existing] + water_existing)

    sp_path = P / "structure-plan" / "structure-plan.geojson"
    standin = not sp_path.exists()
    SP = standin_structure(S, kept_u) if standin else S.layer(sp_path)
    if standin:
        notes.append("No structure plan found: a simple stand-in (site in four quarters, a green cross, one centre) was used to test. Rerun when structure-plan exists.")
    sources.append("Urban figure: " + ("stand-in made by this skill" if standin else "structure-plan/structure-plan.geojson"))
    of = lambda k: [(polys(g.intersection(site)) if g.geom_type.endswith("Polygon") else g.intersection(site.buffer(1)), p)
                    for g, p in SP if p.get("kind") == k and not g.is_empty]
    NB = [(g, p) for g, p in of("neighbourhood") if g.area > 500]
    CEN = [(g, p) for g, p in of("centre") if g.area > 50]
    GREEN = [(g, p) for g, p in of("green") if g.area > 200]
    ROUTES = [(g, p) for g, p in of("route") if not g.is_empty]
    nb_u, cen_u = union([g for g, _ in NB]), union([g for g, _ in CEN])
    for g, p in NB:
        x = kept_u.intersection(g).area
        if x > 5000:
            notes.append(f"Existing green or water of {x / 1e4:.1f} ha lies inside '{p.get('name')}': kept here, so massing should build around it.")

    massing = S.layer(P / "massing" / "massing.geojson")
    m_build = [(g, p) for g, p in massing if p.get("kind") == "building" and not p.get("existing")]
    m_streets = [(g, p) for g, p in massing if p.get("kind") == "street"]
    if massing:
        sources.append("Sealed area: massing/massing.geojson (new roofs and streets)")
    else:
        notes.append("No massing yet: roofs and streets estimated as shares of each neighbourhood (assumptions.md). Rerun after massing for real numbers.")

    C = P / "climate"
    has_climate = C.exists() and any((C / f).exists() for f in ("fresh-air.geojson", "sun-hours.geojson", "radiation.geojson", "rules.geojson"))
    fresh = S.layer(C / "fresh-air.geojson")
    corridor = polys(union([g for g, p in fresh if p.get("kind") == "corridor"]).intersection(site))
    sunh = S.layer(C / "sun-hours.geojson")
    rad = S.layer(C / "radiation.geojson")
    rules = S.layer(C / "rules.geojson")
    noise_bad = union([g for g, p in rules if p.get("kind") == "dont" and p.get("topic") == "noise" and g.geom_type.endswith("Polygon")])
    shaded = union([g for g, p in rules if p.get("kind") == "careful" and p.get("topic") == "sun" and g.geom_type.endswith("Polygon")])
    hmax = max([p.get("hours_max", 0) for _, p in sunh] or [0])
    if sunh and shaded.is_empty:
        shaded = union([g for g, p in sunh if p.get("hours_max", 0) <= hmax / 2])
    sunny = union([g for g, p in sunh if p.get("hours_min", 0) >= 0.75 * hmax]) if sunh else shapely.Polygon()
    if rad:
        vals = sorted({p.get("kwh_min", 0) for _, p in rad})
        cut = vals[int(len(vals) * 2 / 3)] if len(vals) > 2 else vals[-1]
        hot = polys(union([g for g, p in rad if p.get("kwh_min", 0) >= cut]).intersection(site))
        hot_basis = f"radiation >= {cut:g} kWh/m2 a (climate/radiation.geojson, top third)"
    elif sunh:
        hot = polys(sunny.intersection(site))
        hot_basis = "sun hours >= 3/4 of the open-ground maximum (climate/sun-hours.geojson)"
    else:
        hot, hot_basis = shapely.Polygon(), None
    if has_climate:
        sources.append("Climate: climate/ (fresh-air, sun-hours, radiation, rules where present)")
        for f in ("fresh-air", "sun"):
            if (C / f"{f}.json").exists():
                sources += [s for s in read(C / f"{f}.json").get("sources", [])[:2]]
    else:
        notes.append("No climate output: cold-air corridors, hot areas and sunny play spots could not be checked; trees go in squares and along routes near the centres.")

    def sun_at(pt):
        for g, p in sunh:
            if g.contains(pt):
                return p.get("hours_max", 0) / max(hmax, 1)
        return 0.0

    feats = []

    def add(g, **p):
        g = polys(g) if g.geom_type.endswith("Polygon") or g.geom_type in ("GeometryCollection",) else g
        if g.is_empty:
            return None
        if g.geom_type.endswith("Polygon"):
            p.setdefault("area_m2", round(g.area))
        feats.append((g, p))
        return g

    # ---------- green: from the structure plan, the climate corridors, what exists ----------
    for g, lu, name in kept_existing:
        add(g, kind="nature", name=name or lu.split(":")[-1].replace("_", " "), action="keep", public=lu in ("leisure:park",),
            reason="existing green kept", source="site plots.geojson")
    for g in water_existing:
        add(g, kind="retention", type="existing water", action="keep", volume_m3=None, reason="existing water or basin kept, its volume is unknown",
            source="site water.geojson")
    for g, p in GREEN:
        r = roles_of(p)
        if r and all(x in ("energy", "solar", "agriculture") for x in r):
            notes.append(f"Green '{p.get('name', '')}' has roles {r}: kept free, not counted as open space.")
            continue
        g = polys(g.difference(kept_u))
        public = not r or "recreation" in r
        kind = "green-corridor" if elongated(g) else ("park" if public else "nature")
        add(g, kind=kind, name=p.get("name"), roles=r, public=public, action=p.get("action", "new"),
            reason="green of the structure plan" + (", kept open for cold air" if "climate" in r else ""), source="structure-plan")
    green_sp = union([g for g, p in feats if p["kind"] in ("park", "green-corridor", "nature")])
    if not corridor.is_empty:
        extra = polys(corridor.difference(nb_u).difference(cen_u).difference(green_sp).difference(kept_u))
        extra = union([q for q in getattr(extra, "geoms", [extra]) if q.area > 2000])
        add(extra, kind="green-corridor", name="Cold-air meadow", roles=["climate"], public=False, action="new",
            reason="cold-air corridor kept open: meadow, no trees or walls across it", source="climate/fresh-air.geojson")
    conflicts = []
    for g, p in NB + CEN:
        x = corridor.intersection(g).area if not corridor.is_empty else 0
        if x > 1000:
            conflicts.append(dict(name=p.get("name", "?"), kind=p.get("kind"), ha=round(x / 1e4, 2), share_pct=round(100 * x / g.area)))
    if conflicts:
        add(polys(corridor.intersection(union([g for g, _ in NB + CEN]))), kind="conflict", topic="cold air",
            reason="cold-air corridor crosses land planned for building: keep rows and gaps along the air flow, or keep it free",
            source="climate/fresh-air.geojson x structure-plan")

    # ---------- squares at the centres ----------
    main_routes = [g for g, p in ROUTES if p.get("level") in ("main", None)]
    for g, p in CEN:
        lvl = p.get("level", "local")
        area = v("square_main_m2") if lvl == "main" else v("square_local_m2")
        anchor = g.representative_point()
        ang = 0
        near = [r for r in main_routes if r.distance(g) < 60]
        if near:
            r = min(near, key=lambda r: r.distance(g.centroid))
            line = r if r.geom_type == "LineString" else min(r.geoms, key=lambda q: q.distance(g.centroid))
            pt = nearest_points(g, line)[0]
            anchor = pt if g.buffer(1).contains(pt) else anchor
            ang = line_angle(line, anchor)
        sq = polys(oriented_box(anchor, area, ang).intersection(g.buffer(5)))
        if sq.area < 0.6 * area:
            sq = polys(oriented_box(g.representative_point(), area, ang).intersection(g.buffer(5)))
        add(sq, kind="square", name=f"{p.get('name', 'Centre')} square", level=lvl, action="new",
            reason=f"square at the {lvl} centre", source=T["square_main_m2" if lvl == "main" else "square_local_m2"][1])

    # ---------- public green within reach; parks in neighbourhoods that lack it ----------
    reach, pocket = v("reach_m"), v("pocket_park_m2")
    pub = lambda: union([g for g, p in feats if p["kind"] in ("park", "green-corridor", "nature") and p.get("public")
                         and g.area >= min(pocket, 5000)] + [g for g, p in feats if p["kind"] == "park"])
    taken = {}
    for g, p in sorted(NB, key=lambda f: -f[0].area):
        for _ in range(6):
            pg = pub()
            pts = grid_points(g, 20)
            if not pts:
                break
            d = shapely.distance(np.array(pts, dtype=object), pg) if not pg.is_empty else np.full(len(pts), 1e9)
            if d.max() <= reach:
                break
            far = pts[int(np.argmax(d))]
            # pull the park to the middle of the area it has to serve
            serve = [q for q, dd in zip(pts, d) if dd > reach and q.distance(far) < reach]
            c = Point(np.mean([q.x for q in serve]), np.mean([q.y for q in serve])) if serve else far
            core = polys(g.buffer(-math.sqrt(pocket) * 0.6))  # far enough from the edge for a whole park
            c = nearest_points(core, c)[0] if not core.is_empty else (c if g.contains(c) else far)
            park = polys(oriented_box(c, pocket, 0, 1.2).intersection(g))
            if park.area < 0.5 * pocket:
                break
            add(park, kind="park", name=f"{p.get('name', 'Neighbourhood')} park", public=True, action="new", in_neighbourhood=p.get("name"),
                reason=f"no public green within {reach} m", source=T["reach_m"][1])
            taken[p.get("name")] = taken.get(p.get("name"), 0) + park.area
    pub_area = pub().area
    res = v("residents")
    target_green = res * v("public_green_m2_per_resident") if res and v("public_green_m2_per_resident") else None
    if target_green and pub_area < target_green:
        short = target_green - pub_area
        tot = sum(g.area for g, _ in NB) or 1
        for g, p in NB:
            need = short * g.area / tot
            if need < 1000:
                continue
            pg = pub()
            pts = grid_points(g, 20)
            if not pts:
                continue
            d = shapely.distance(np.array(pts, dtype=object), pg)
            c = pts[int(np.argmax(d))]
            park = polys(oriented_box(c, need, 0, 1.2).intersection(g))
            add(park, kind="park", name=f"{p.get('name', 'Neighbourhood')} green", public=True, action="new", in_neighbourhood=p.get("name"),
                reason=f"to meet {v('public_green_m2_per_resident')} m2 public green per resident", source=T["public_green_m2_per_resident"][1])
            taken[p.get("name")] = taken.get(p.get("name"), 0) + park.area
        pub_area = pub().area

    # ---------- playgrounds: in the sun, out of noise and shade, near each neighbourhood ----------
    play_rate, play_min = v("play_m2_per_resident"), v("play_min_m2")
    tot_nb = sum(g.area for g, _ in NB) or 1
    used = union([g for g, p in feats if p["kind"] in ("square", "retention", "conflict")])
    play_total = 0
    if not (play_rate and res) and not play_min:
        notes.append("No play area numbers in targets.json: no playgrounds placed. Take them from the brief.")
    else:
        for g, p in NB:
            need = max(play_min or 0, (play_rate or 0) * (res or 0) * g.area / tot_nb)
            cand = polys(union([q for q, pp in feats if pp["kind"] in ("park", "green-corridor") and pp.get("public", True)])
                         .intersection(g.buffer(reach)).difference(used).difference(noise_bad).difference(shaded))
            spot, how = None, ""
            r0 = math.sqrt(need / math.pi)
            core = polys(cand.buffer(-r0 * 0.6))
            pts = grid_points(core if not core.is_empty else cand, 10)
            if pts:
                score = [(sun_at(q) if sunh else 0) - 0.5 * q.distance(g) / reach - 0.2 * q.distance(g.centroid) / (reach * 3) for q in pts]
                spot = pts[int(np.argmax(score))]
                how = "sunniest spot in nearby public green" if sunh else "nearby public green (no sun data)"
            else:
                inner = polys(g.difference(noise_bad).difference(shaded).difference(used))
                pts = grid_points(inner, 10)
                if pts:
                    spot = min(pts, key=lambda q: q.distance(g.centroid))
                    how = "inside the neighbourhood: no public green nearby"
                    taken[p.get("name")] = taken.get(p.get("name"), 0) + need
            if spot is None:
                notes.append(f"No place for a playground for '{p.get('name')}' outside noise and shade.")
                continue
            pl = grow(polys((cand if "public green" in how else g).difference(used)), spot, need)
            pl = add(pl, kind="playground", name=f"Play, {p.get('name', '')}", area_target_m2=round(need), action="new",
                     sun_share=round(sun_at(pl.representative_point()), 2) if sunh else None, reason=how,
                     source=f"{T['play_m2_per_resident'][1]}; {T['play_min_m2'][1]}")
            if pl is not None:
                used = used.union(pl)
                play_total += pl.area

    # ---------- rainwater: catchments, swales along the green edge, basins in the green ----------
    h = v("design_rain_mm") / 1000
    dur = v("design_rain_duration_min") * 60
    psi_roof = v("runoff_roof") * (1 - v("green_roof_share")) + v("runoff_green_roof") * v("green_roof_share")
    squares = [(g, p) for g, p in feats if p["kind"] == "square"]
    catch, cfeats = [], []
    for g, p in NB + CEN:
        if massing:
            roof = sum(b.intersection(g).area for b, _ in m_build)
            road = sum(polys(s if s.geom_type.endswith("Polygon") else s.buffer(float(sp.get("width", 10)) / 2, cap_style=2)).intersection(g).area
                       for s, sp in m_streets)
            basis = "massing"
        else:
            roof, road = g.area * v("roof_share"), g.area * v("road_share")
            basis = "shares of land (no massing)"
        sq = sum(s.intersection(g).area for s, _ in squares)
        au = roof * psi_roof + road * v("runoff_road") + sq * v("runoff_square")
        vol = max(au * h - v("throttle_l_s_ha") * g.area / 1e4 * dur / 1000, 0)
        catch.append(dict(g=g, name=p.get("name", "?"), kind=p.get("kind"), au=au, vol=vol, roof=roof, road=road, sq=sq, basis=basis))
    greens_for_water = polys(union([q for q, pp in feats if pp["kind"] in ("park", "green-corridor")]).difference(used))
    water_role = union([q for q, pp in feats if "water" in (pp.get("roles") or [])])
    sw_d, bs_d, kf, sw_w = v("swale_depth_m"), v("basin_depth_m"), v("slope_factor"), v("swale_width_m")
    taken_w = shapely.Polygon()
    for c in sorted(catch, key=lambda c: -c["vol"]):
        g, left = c["g"], c["vol"]
        c["provided"] = 0
        if left <= 0:
            continue
        free = polys(greens_for_water.difference(taken_w))
        strip = polys(free.intersection(g.buffer(sw_w + 2)).difference(g.buffer(2)))
        ref = water_role if not water_role.is_empty else g.centroid
        if strip.area > 50:
            anchor = nearest_points(strip, ref)[0]
            need_a = left / sw_d * kf
            sw = grow(strip, anchor, need_a)
            vol = min(sw.area / kf * sw_d, left)
            add(sw, kind="retention", type="swale", catchment=c["name"], depth_m=sw_d, volume_m3=round(vol), action="new",
                reason="swale along the neighbourhood's green edge: rain from roofs and streets soaks away and evaporates",
                source=T["design_rain_mm"][1])
            taken_w, left = taken_w.union(sw), left - vol
            c["provided"] += vol
        if left > 1:
            free = polys(greens_for_water.difference(taken_w).difference(g.buffer(sw_w + 6)))
            near = polys(free.intersection(g.buffer(reach)))
            pref = polys(near.intersection(water_role))
            region = pref if pref.area > left / bs_d * kf * 0.8 else near
            if region.area > 100:
                anchor = nearest_points(region, g)[0]
                bs = grow(region, anchor, left / bs_d * kf * 1.1)
                soft = polys(bs.buffer(-4).buffer(4))
                bs = soft if soft.area > 0.85 * bs.area else bs
                vol = min(bs.area / kf * bs_d, left)
                add(bs, kind="retention", type="basin", catchment=c["name"], depth_m=bs_d, volume_m3=round(vol), action="new",
                    reason="retention basin in the green next to the neighbourhood" + (", on green the structure plan gives to water" if region is pref else ""),
                    source=T["design_rain_mm"][1])
                taken_w, left = taken_w.union(bs), left - vol
                c["provided"] += vol
        if left > 50:
            c["inside"] = round(left)
            notes.append(f"'{c['name']}': {round(left)} m3 has no room in the green nearby; hold it inside (retention square, green roofs, tank).")
        cfeats.append((g, dict(kind="catchment", name=c["name"], of=c["kind"], sealed_basis=c["basis"], roof_m2=round(c["roof"]), road_m2=round(c["road"]),
                               square_m2=round(c["sq"]), connected_m2=round(c["au"]), volume_m3=round(c["vol"]), provided_m3=round(c["provided"]),
                               inside_m3=c.get("inside", 0))))
    cfeats += [(c["g"], dict(kind="catchment", name=c["name"], of=c["kind"], sealed_basis=c["basis"], roof_m2=round(c["roof"]), road_m2=round(c["road"]),
                             square_m2=round(c["sq"]), connected_m2=round(c["au"]), volume_m3=0, provided_m3=0, inside_m3=0))
               for c in catch if c["vol"] <= 0]

    # ---------- trees: squares, hot routes and hot park edges; none in cold-air corridors ----------
    trees, no_tree = [], union([q for q, pp in feats if pp["kind"] in ("retention", "playground", "conflict")] + [corridor])
    spacing, sgrid = v("tree_spacing_m"), v("square_tree_grid_m")
    for g, p in squares:
        for q in grid_points(polys(g.buffer(-3)), sgrid):
            if not no_tree.contains(q):
                trees.append((q, "shade on the square" + (", hot area" if not hot.is_empty and hot.contains(q) else "")))
    if not m_streets:
        zone = hot if not hot.is_empty else cen_u.buffer(150)
        for r, p in ROUTES:
            if p.get("level") == "landscape":
                continue
            for line in getattr(r, "geoms", [r]):
                for dd in np.arange(spacing / 2, line.length, spacing):
                    c0, c1 = line.interpolate(max(dd - 1, 0)), line.interpolate(min(dd + 1, line.length))
                    dx, dy = c1.x - c0.x, c1.y - c0.y
                    n = math.hypot(dx, dy) or 1
                    for s in (-8, 8):
                        q = Point(line.interpolate(dd).x - dy / n * s, line.interpolate(dd).y + dx / n * s)
                        if zone.contains(q) and site.contains(q) and not no_tree.contains(q) and not cen_u.contains(q):
                            trees.append((q, "street tree, hot area" if not hot.is_empty else "street tree near a centre"))
    else:
        notes.append("Street trees come from massing; this skill adds trees in squares and parks only.")
    if not hot.is_empty:
        for g, p in [(q, pp) for q, pp in feats if pp["kind"] == "park"]:
            band = polys(g.buffer(-4).difference(g.buffer(-16)).intersection(hot))
            for q in grid_points(band, 14):
                if not no_tree.contains(q):
                    trees.append((q, "shade grove, hot area"))
    seen = []
    for q, why in trees:
        if all(q.distance(s) > 6 for s in seen[-400:]):
            seen.append(q)
            feats.append((q, dict(kind="tree", action="new", reason=why, source=hot_basis or T["tree_spacing_m"][1])))

    # ---------- numbers ----------
    green_kinds = ("park", "green-corridor", "nature", "playground")
    green_u = polys(union([g for g, p in feats if p["kind"] in green_kinds] +
                          [g for g, p in feats if p["kind"] == "retention" and p.get("type") in ("swale", "basin")]).intersection(site))
    sq_u = union([g for g, _ in squares])
    req = sum(c["vol"] for c in catch)
    prov = sum(c.get("provided", 0) for c in catch)
    rows = []
    for c in catch:
        g = c["g"]
        pts = grid_points(g, 25)
        pg = pub()
        far = float(shapely.distance(np.array(pts, dtype=object), pg).max()) if pts and not pg.is_empty else None
        rows.append(dict(area=c["name"], kind=c["kind"], area_ha=round(g.area / 1e4, 2),
                         green_in_area_pct=round(100 * green_u.intersection(g).area / g.area, 1),
                         land_for_parks_m2=round(taken.get(c["name"], 0)), connected_m2=round(c["au"]),
                         retention_m3=round(c["vol"]), retention_provided_m3=round(c.get("provided", 0)),
                         farthest_from_public_green_m=round(far) if far is not None else None))
    K = dict(
        standin_structure_plan=standin,
        site_area_ha=round(site.area / 1e4, 2),
        green_ha=round(green_u.area / 1e4, 2), green_pct_site=round(100 * green_u.area / site.area, 1),
        public_green_m2=round(pub_area), public_green_target_m2=round(target_green) if target_green else None,
        public_green_m2_per_resident=round(pub_area / res, 1) if res else None,
        squares_m2=round(sq_u.area), play_m2=round(play_total),
        play_target_m2=round(max(play_min or 0, (play_rate or 0) * (res or 0))) if (play_rate and res) or play_min else None,
        trees_new=sum(1 for _, p in feats if p["kind"] == "tree"),
        design_rain_mm=v("design_rain_mm"), design_rain_duration_min=v("design_rain_duration_min"),
        connected_area_ha=round(sum(c["au"] for c in catch) / 1e4, 2),
        retention_required_m3=round(req), retention_provided_m3=round(prov),
        retention_area_m2=round(sum(g.area for g, p in feats if p["kind"] == "retention" and p.get("action") == "new")),
        land_taken_from_neighbourhoods_m2=round(sum(taken.values())),
        cold_air_conflicts=conflicts, hot_area_basis=hot_basis,
        sources=sources, notes=notes,
    )
    S.write_geojson(out / "open-space.geojson", feats)
    S.write_geojson(out / "catchments.geojson", cfeats)
    write_json(out / "key-numbers.json", K)
    with open(out / "key-numbers.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["area"])
        w.writeheader()
        w.writerows(rows)
        if rows:
            w.writerow(dict(area="SITE", kind="site", area_ha=K["site_area_ha"], green_in_area_pct=K["green_pct_site"],
                            land_for_parks_m2=K["land_taken_from_neighbourhoods_m2"], connected_m2=round(sum(c["au"] for c in catch)),
                            retention_m3=K["retention_required_m3"], retention_provided_m3=K["retention_provided_m3"]))
    lines = ["# Assumptions and sources", "", "Every number this skill used, and where it comes from. Lines marked *assumption* are defaults: replace them in `targets.json` with the brief's or the city's values.", ""]
    lines += [f"- `{k}`: {T[k][0]} ({T[k][1]})" for k in DEFAULTS if T[k][0] is not None]
    lines += ["", "## Inputs", ""] + [f"- {s}" for s in sources] + ["", "## Notes", ""] + [f"- {n}" for n in notes]
    (out / "assumptions.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_summary(out, K, defaulted)
    print({k: K[k] for k in ("green_pct_site", "public_green_m2", "public_green_target_m2", "play_m2", "play_target_m2", "trees_new",
                              "retention_required_m3", "retention_provided_m3", "land_taken_from_neighbourhoods_m2")})
    for n in notes:
        print("-", n)


def write_summary(out, K, defaulted):
    n = lambda x: f"{x:,}".replace(",", "\u202f")
    s = []
    lead = "On a stand-in structure plan (none exists yet), the" if K["standin_structure_plan"] else "The"
    s.append(f"{lead} open space takes {K['green_pct_site']} % of the {K['site_area_ha']} ha site as green: parks, green corridors{', playgrounds' if K['play_m2'] else ''} and "
             f"{n(K['retention_area_m2'])} m² of swales and basins, plus {n(K['squares_m2'])} m² of squares and {n(K['trees_new'])} new trees.")
    if K["public_green_target_m2"]:
        ok = "meets" if K["public_green_m2"] >= K["public_green_target_m2"] else "falls short of"
        s.append(f"Public green is {n(K['public_green_m2'])} m², which {ok} the brief's {n(K['public_green_target_m2'])} m²"
                 + (f", and play areas are {n(K['play_m2'])} m² against {n(K['play_target_m2'])} m²." if K["play_target_m2"] else "."))
    s.append(f"Holding a {K['design_rain_mm']} mm rain from {K['connected_area_ha']} ha of connected roofs, streets and squares needs "
             f"{n(K['retention_required_m3'])} m³ of retention; {n(K['retention_provided_m3'])} m³ fits in the green.")
    if K["cold_air_conflicts"]:
        s.append("The cold-air corridor crosses " + ", ".join(f"{c['name']} ({c['ha']} ha)" for c in K["cold_air_conflicts"])
                 + ": massing should keep it free or build along the air flow.")
    unsure = []
    if "design_rain_mm" in defaulted:
        unsure.append("the design rain is an assumption, not the local statistic")
    if any("No massing" in n for n in K["notes"]):
        unsure.append("the sealed area is estimated until massing exists")
    unsure.append("without terrain the retention sits by the green edge, not checked against the falls of the land")
    s.append("Least sure: " + "; ".join(unsure) + ".")
    (out / "summary.md").write_text(" ".join(s) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
