"""Draw the open-space proposal as maps: SVG with a PNG next to each, with legend, north arrow, scale bar and sources.

python draw.py --site SITE_DIR --proposal PROPOSAL_DIR [--out PROPOSAL/open-space] [--style style.json] [--scale 5000] [--margin 150]

The look comes from style.json, made from drawing-graphics/standard.md (keys, all optional: paper, ink, accent, context, water,
font, thin, mid, thick, text, title; line weights and text sizes in mm). Without it: black on white with one accent, and
water as a black line hatch. Maps: open-space (the plan), rainwater (catchments and retention), climate-fit (only with climate output).
"""
import argparse
import math
import re
import textwrap
from pathlib import Path
from xml.sax.saxutils import escape

import shapely
import shapely.ops
from shapely.geometry import box

from common import Site, mix, png, polys, read, style, union

SCALES = [500, 1000, 2000, 2500, 3000, 5000, 7500, 10000, 15000, 20000, 25000, 50000]


def nice(x):
    p = 10 ** math.floor(math.log10(x))
    return max(m * p for m in (1, 2, 5) if m * p <= x)


def fmt(x):
    return f"{round(x):,}".replace(",", "\u202f")


class Map:
    SIDE, PAD, HEAD, FOOT = 82, 10, 17, 26

    def __init__(self, S, st, extent, scale, title, subtitle):
        self.S, self.st, self.scale, self.extent = S, st, scale, extent
        self.x0, self.y0, self.x1, self.y1 = extent.bounds
        self.k = 1000 / scale
        self.mw, self.mh = (self.x1 - self.x0) * self.k, (self.y1 - self.y0) * self.k
        self.W = self.PAD * 3 + self.mw + self.SIDE
        self.H = self.PAD * 2 + self.HEAD + max(self.mh, 170) + self.FOOT
        self.ox, self.oy = self.PAD, self.PAD + self.HEAD
        self.title, self.subtitle = title, subtitle
        self.body, self.labels, self.defs, self.legend, self.facts = [], [], [], [], []
        self._ids = set()

    def P(self, x, y):
        return self.ox + (x - self.x0) * self.k, self.oy + (self.y1 - y) * self.k

    def d(self, g):
        out = []
        for part in getattr(g, "geoms", [g]):
            t = part.geom_type
            if t == "Polygon":
                out += ["M" + "L".join("%.2f %.2f" % self.P(x, y) for x, y in r.coords) + "Z" for r in [part.exterior, *part.interiors]]
            elif t == "LineString":
                out.append("M" + "L".join("%.2f %.2f" % self.P(x, y) for x, y in part.coords))
            elif hasattr(part, "geoms"):
                out.append(self.d(part))
        return "".join(out)

    def add(self, g, **a):
        if g is None or g.is_empty:
            return
        g = shapely.make_valid(g).intersection(self.extent)
        if g.is_empty:
            return
        if "marker_end" in a and hasattr(g, "geoms"):
            for part in g.geoms:
                self.add(part, **a)
            return
        attrs = " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in a.items())
        self.body.append(f'<path d="{self.d(g)}" fill-rule="evenodd" {attrs}/>')

    def circles(self, pts, r_m, **a):
        attrs = " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in a.items())
        r = max(r_m * self.k, 0.35)
        for p in pts:
            if self.extent.contains(p):
                x, y = self.P(p.x, p.y)
                self.body.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r:.2f}" {attrs}/>')

    def pattern(self, name, svg, size):
        if name not in self._ids:
            self._ids.add(name)
            self.defs.append(f'<pattern id="{name}" width="{size}" height="{size}" patternUnits="userSpaceOnUse">{svg}</pattern>')
        return f"url(#{name})"

    def hatch(self, name, color, gap=1.4, angle=45, w=None, bg="none"):
        if name not in self._ids:
            self._ids.add(name)
            self.defs.append(f'<pattern id="{name}" width="{gap}" height="{gap}" patternUnits="userSpaceOnUse" patternTransform="rotate({angle})">'
                             f'<rect width="{gap}" height="{gap}" fill="{bg}"/><line x1="0" y1="0" x2="0" y2="{gap}" stroke="{color}" stroke-width="{w or self.st["thin"] * 1.5}"/></pattern>')
        return f"url(#{name})"

    def dots(self, name, color, gap=1.4, r=0.22, bg="none"):
        return self.pattern(name, f'<rect width="{gap}" height="{gap}" fill="{bg}"/><circle cx="{gap / 2}" cy="{gap / 2}" r="{r}" fill="{color}"/>', gap)

    def text(self, x, y, s, size=None, weight="normal", anchor="start", fill=None, style_=""):
        st = self.st
        return (f'<text x="{x:.2f}" y="{y:.2f}" font-family="{escape(st["font"])}" font-size="{size or st["text"]}" font-weight="{weight}" '
                f'text-anchor="{anchor}" fill="{fill or st["ink"]}" {style_}>{escape(str(s))}</text>')

    def label(self, g, s, size=None, italic=False, halo=True):
        p = g.representative_point() if g.geom_type.endswith("Polygon") else g.interpolate(0.5, normalized=True)
        if not self.extent.contains(p):
            return
        x, y = self.P(p.x, p.y)
        sz = size or self.st["text"] * 0.85
        st = f'font-style="{"italic" if italic else "normal"}"'
        for i, ln in enumerate(s.split("\n")):
            yy = y + (i - (s.count("\n")) / 2) * sz * 1.15 + sz * 0.35
            if halo:
                self.labels.append(self.text(x, yy, ln, sz, anchor="middle", fill=self.st["paper"],
                                             style_=f'{st} stroke="{self.st["paper"]}" stroke-width="{sz * 0.25:.2f}" stroke-linejoin="round"'))
            self.labels.append(self.text(x, yy, ln, sz, anchor="middle", style_=st))

    def key(self, kind, look, label, **o):
        self.legend.append((kind, look, label, o))

    def context(self, buildings=True):
        st, S = self.st, self.S
        water = st["water"] or self.hatch("ctxwater", st["ink"], 0.9, 90, st["thin"])
        for g, _ in S.site_layer("water"):
            self.add(g, fill=water if g.geom_type.endswith("Polygon") else "none", stroke=st["ink"] if not st["water"] else st["water"], stroke_width=st["thin"])
        for g, p in S.site_layer("streets"):
            hw = str(p.get("highway", p.get("type", "")))
            w = st["mid"] if hw in ("motorway", "trunk", "primary", "secondary") else st["thin"]
            if hw in ("footway", "path", "steps", "track", "cycleway"):
                continue
            self.add(g, fill="none", stroke=st["context"], stroke_width=w)
        for g, _ in S.site_layer("rail"):
            self.add(g, fill="none", stroke=st["ink"], stroke_width=st["thin"], stroke_dasharray="1.2 0.8")
        if buildings:
            self.add(union([g for g, _ in S.site_layer("buildings")]), fill=st["context"], stroke="none")
            self.key("fill", st["context"], "Existing buildings")

    def site(self):
        self.add(self.S.poly, fill="none", stroke=self.st["ink"], stroke_width=self.st["thick"], stroke_dasharray="3 1.2")
        self.key("line", self.st["ink"], "Project site", dash="3 1.2", w=self.st["thick"])

    def save(self, path, sources):
        st = self.st
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.W:.1f}mm" height="{self.H:.1f}mm" viewBox="0 0 {self.W:.1f} {self.H:.1f}">',
             f'<defs>{"".join(self.defs)}<clipPath id="frame"><rect x="{self.ox}" y="{self.oy}" width="{self.mw:.2f}" height="{self.mh:.2f}"/></clipPath>'
             f'<marker id="arrow" viewBox="0 0 6 6" refX="5" refY="3" markerUnits="userSpaceOnUse" markerWidth="2.2" markerHeight="2.2" orient="auto">'
             f'<path d="M0 0L6 3L0 6z" fill="{st["ink"]}"/></marker></defs>',
             f'<rect width="100%" height="100%" fill="{st["paper"]}"/>',
             f'<g clip-path="url(#frame)">{"".join(self.body)}{"".join(self.labels)}</g>',
             f'<rect x="{self.ox}" y="{self.oy}" width="{self.mw:.2f}" height="{self.mh:.2f}" fill="none" stroke="{st["ink"]}" stroke-width="{st["mid"]}"/>',
             self.text(self.ox, self.PAD + st["title"], self.title, st["title"], "bold"),
             self.text(self.ox, self.PAD + st["title"] + 5.5, self.subtitle)]
        x, y = self.ox + self.mw + self.PAD, self.oy + 4
        o.append(self.text(x, y, "Legend", st["text"] * 1.2, "bold"))
        y += 6
        for kind, look, label, opt in self.legend:
            lines = textwrap.wrap(label, 44) or [""]
            if kind == "fill":
                o.append(f'<rect x="{x}" y="{y - 3}" width="7" height="4" fill="{look}" stroke="{opt.get("stroke", st["ink"])}" stroke-width="{st["thin"]}"/>')
            elif kind == "line":
                o.append(f'<line x1="{x}" y1="{y - 1}" x2="{x + 7}" y2="{y - 1}" stroke="{look}" stroke-width="{opt.get("w", st["mid"])}" stroke-dasharray="{opt.get("dash", "none")}"/>')
            elif kind == "arrow":
                o.append(f'<line x1="{x}" y1="{y - 1}" x2="{x + 7}" y2="{y - 1}" stroke="{look}" stroke-width="{st["mid"]}" marker-end="url(#arrow)"/>')
            elif kind == "dot":
                o.append(f'<circle cx="{x + 3.5}" cy="{y - 1}" r="{opt.get("r", 1)}" fill="{look}" stroke="{st["paper"]}" stroke-width="{st["thin"]}"/>')
            for i, ln in enumerate(lines):
                o.append(self.text(x + 9, y + i * st["text"] * 1.25, ln))
            y += len(lines) * st["text"] * 1.25 + 2.2
        if self.facts:
            y += 4
            o.append(self.text(x, y, "Key numbers", st["text"] * 1.2, "bold"))
            y += 5.5
            for f in self.facts:
                for ln in textwrap.wrap(f, 52):
                    o.append(self.text(x, y, ln))
                    y += st["text"] * 1.25
                y += 1
        y = max(y + 8, self.oy + self.mh - 36)
        o.append(f'<path d="M{x + 5} {y}L{x + 9} {y + 12}L{x + 5} {y + 9}L{x + 1} {y + 12}Z" fill="{st["ink"]}"/>')
        o.append(self.text(x + 5, y - 1.5, "N", st["text"] * 1.3, "bold", "middle"))
        L = nice((self.SIDE - 14) / self.k)
        y += 22
        for i in range(4):
            o.append(f'<rect x="{x + i * L * self.k / 4:.2f}" y="{y}" width="{L * self.k / 4:.2f}" height="1.6" '
                     f'fill="{st["ink"] if i % 2 == 0 else st["paper"]}" stroke="{st["ink"]}" stroke-width="{st["thin"]}"/>')
        o.append(self.text(x, y + 5, "0"))
        o.append(self.text(x + L * self.k, y + 5, f"{L:g} m", anchor="middle"))
        o.append(self.text(x, y + 9.5, f"1:{fmt(self.scale)} at {self.W:.0f} × {self.H:.0f} mm"))
        fy = self.oy + max(self.mh, 170) + 6
        o.append(self.text(self.ox, fy, "Sources", weight="bold"))
        src = list(dict.fromkeys(sources)) + [f"Projection {self.S.crs.name}."]
        for ln in textwrap.wrap("  ·  ".join(src), int((self.W - 2 * self.PAD) / (st["text"] * 0.47)))[:5]:
            fy += st["text"] * 1.3
            o.append(self.text(self.ox, fy, ln, st["text"] * 0.9))
        o.append("</svg>")
        path.write_text("\n".join(o), encoding="utf-8")
        how = png(path, self.W, self.H)
        return path.name, how


def attribution(site_dir):
    p = Path(site_dir) / "SOURCES.md"
    if p.exists():
        m = re.search(r"^>\s*(.+)$", p.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip()
    return "Base map: the project's site folder (see its SOURCES.md)."


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", required=True)
    ap.add_argument("--proposal", required=True)
    ap.add_argument("--out")
    ap.add_argument("--style")
    ap.add_argument("--scale", type=int)
    ap.add_argument("--margin", type=float, default=150)
    a = ap.parse_args()
    S, P = Site(a.site), Path(a.proposal)
    out = Path(a.out or P / "open-space")
    st = style(a.style)
    K = read(out / "key-numbers.json")
    F = S.layer(out / "open-space.geojson")
    CA = S.layer(out / "catchments.geojson")
    sp = P / "structure-plan" / "structure-plan.geojson"
    SP = S.layer(sp)
    ext = box(*S.poly.buffer(a.margin).bounds)
    w, h = ext.bounds[2] - ext.bounds[0], ext.bounds[3] - ext.bounds[1]
    scale = a.scale or next((s for s in SCALES if w * 1000 / s <= 380 and h * 1000 / s <= 380), SCALES[-1])
    look = "the drawing standard" if st["from_standard"] else "fallback look (no drawing standard): black on white, one accent"
    stand = K.get("standin_structure_plan") or (sp.exists() and "STAND-IN" in sp.read_text(encoding="utf-8"))
    base_src = [attribution(a.site), "Proposal: open-space skill, on " + ("a STAND-IN structure plan" if stand else "structure-plan")]
    base_src += [s for s in K.get("sources", []) if "STAND-IN" in s.upper()]
    base_src.append("Numbers and assumptions: open-space/assumptions.md")
    by = lambda *kinds: [(g, p) for g, p in F if p.get("kind") in kinds]

    acc, ink, paper = st["accent"], st["ink"], st["paper"]
    look_ = dict(
        park=mix(paper, acc, 0.42),
        corridor=None, nature=None,
        play=mix(acc, ink, 0.15),
        square=mix(paper, st["context"], 0.55),
        tree=mix(acc, ink, 0.45),
        nb=mix(paper, st["context"], 0.25),
    )
    made = []

    def water_fill(m):
        return st["water"] or m.hatch("water", ink, 0.5, 90, st["thin"] * 1.4, paper)

    def neighbourhoods(m, label=True):
        for g, p in SP:
            if p.get("kind") in ("neighbourhood", "centre"):
                m.add(g, fill=look_["nb"], stroke=st["context"], stroke_width=st["thin"])
                if label and p.get("kind") == "neighbourhood" and g.area > 20000:
                    m.label(g, p.get("name", ""), italic=True)
        m.key("fill", look_["nb"], "Neighbourhoods and centres of the structure plan (for building)", stroke=st["context"])

    def greens(m, legend=True):
        corr_fill = m.hatch("corr", acc, 1.2, 45, st["thin"] * 1.6, mix(paper, acc, 0.14))
        nat_fill = m.dots("nat", acc, 1.3, 0.28, mix(paper, acc, 0.22))
        for g, p in by("nature"):
            m.add(g, fill=nat_fill, stroke=acc, stroke_width=st["thin"])
        for g, p in by("green-corridor"):
            m.add(g, fill=corr_fill, stroke=acc, stroke_width=st["thin"])
        for g, p in by("park"):
            m.add(g, fill=look_["park"], stroke=acc, stroke_width=st["thin"])
        if legend:
            if by("park"):
                m.key("fill", look_["park"], "Park, public green (new parks inside neighbourhoods where none is within reach)", stroke=acc)
            if by("green-corridor"):
                m.key("fill", corr_fill, "Green corridor: meadow and paths, kept open for air and species", stroke=acc)
            if by("nature"):
                m.key("fill", nat_fill, "Nature and existing green kept (biotopes, woods, compensation)", stroke=acc)

    def retention(m, label=False, legend=True):
        wf = water_fill(m)
        for g, p in by("retention"):
            dash = "0.8 0.5" if p.get("type") == "swale" else "none"
            m.add(g, fill=wf, stroke=st["water"] or ink, stroke_width=st["mid"], stroke_dasharray=dash)
        if label:
            for g, p in by("retention"):
                if p.get("volume_m3") and g.area > 1500:
                    m.label(g, f'{fmt(p["volume_m3"])} m³', st["text"] * 0.75)
        if legend and by("retention"):
            if by("retention") and any(p.get("type") == "swale" for _, p in by("retention")):
                m.key("fill", wf, f"Swale along the green edge, {K.get('design_rain_mm')} mm rain, about 0.3 m deep", stroke=ink)
            if any(p.get("type") == "basin" for _, p in by("retention")):
                m.key("fill", wf, "Retention basin in the green", stroke=ink)
            if any(p.get("type") == "existing water" for _, p in by("retention")):
                m.key("fill", wf, "Existing water or basin, kept", stroke=ink)

    def squares_play_trees(m, legend=True):
        for g, p in by("square"):
            m.add(g, fill=look_["square"], stroke=ink, stroke_width=st["mid"])
        for g, p in by("playground"):
            m.add(g, fill=look_["play"], stroke=paper, stroke_width=st["thin"])
        m.circles([g for g, _ in by("tree")], 4, fill=look_["tree"], stroke=paper, stroke_width=st["thin"] * 0.6)
        if legend:
            if by("square"):
                m.key("fill", look_["square"], "Square at a centre, permeable paving")
            if by("playground"):
                m.key("fill", look_["play"], f"Playground ({fmt(K.get('play_m2') or 0)} m² in all)", stroke=paper)
            if by("tree"):
                m.key("dot", look_["tree"], f"New tree, crown 8 m ({K.get('trees_new')} in all)", r=1.1)

    # ---------- 1. the plan ----------
    m = Map(S, st, ext, scale, "Open space", "Parks, squares, green corridors, play and the blue-green network")
    m.context()
    neighbourhoods(m)
    greens(m)
    retention(m)
    squares_play_trees(m)
    m.site()
    m.facts = [f"Green: {K['green_pct_site']} % of the site ({K['green_ha']} ha)",
               f"Public green: {fmt(K['public_green_m2'])} m²" + (f" (brief: {fmt(K['public_green_target_m2'])} m²)" if K.get("public_green_target_m2") else ""),
               f"Squares: {fmt(K['squares_m2'])} m²",
               f"Retention: {fmt(K['retention_provided_m3'])} of {fmt(K['retention_required_m3'])} m³"]
    made.append(m.save(out / "open-space.svg", base_src))

    # ---------- 2. rainwater ----------
    m = Map(S, st, ext, scale, "Rainwater", f"Where a {K['design_rain_mm']} mm rain falls, and where it is held")
    m.context()
    vals = [p["connected_m2"] / max(g.area, 1) for g, p in CA] or [0]
    lo, hi = min(vals), max(vals)
    tint = lambda r: mix(paper, ink, 0.08 + 0.22 * ((r - lo) / (hi - lo) if hi > lo else 0.5))
    for g, p in CA:
        m.add(g, fill=tint(p["connected_m2"] / max(g.area, 1)), stroke=ink, stroke_width=st["thin"])
    greens(m, legend=False)
    m.add(union([g for g, _ in by("park", "green-corridor", "nature")]), fill="none", stroke=acc, stroke_width=st["thin"])
    m.key("fill", tint(hi), "Catchment: neighbourhood or centre, toned by its sealed share (roofs, streets, squares)")
    m.key("fill", mix(paper, acc, 0.42), "Green that takes the water", stroke=acc)
    retention(m, label=True)
    cg = {p["name"]: g for g, p in CA}
    for g, p in by("retention"):
        c = cg.get(p.get("catchment"))
        if c is not None and p.get("type") in ("swale", "basin"):
            tip = shapely.ops.nearest_points(g, c.centroid)[0]
            d = max(tip.distance(c.centroid), 1)
            back = min(70, d)
            start = shapely.Point(tip.x + (c.centroid.x - tip.x) / d * back, tip.y + (c.centroid.y - tip.y) / d * back)
            if back > 20:
                m.add(shapely.LineString([start, tip]), fill="none", stroke=ink, stroke_width=st["mid"], marker_end="url(#arrow)")
    m.key("arrow", ink, "Runoff from a catchment to its retention")
    for g, p in CA:
        if g.area > 15000:
            m.label(g, f'{p["name"]}\n{fmt(p["volume_m3"])} m³', st["text"] * 0.8, italic=False)
    m.site()
    m.facts = [f"Connected area: {K['connected_area_ha']} ha",
               f"Design rain: {K['design_rain_mm']} mm in {K['design_rain_duration_min']} min",
               f"Needed: {fmt(K['retention_required_m3'])} m³, held in the green: {fmt(K['retention_provided_m3'])} m³",
               f"Water surface: {fmt(K['retention_area_m2'])} m²"]
    made.append(m.save(out / "rainwater.svg", base_src))

    # ---------- 3. climate fit ----------
    C = P / "climate"
    fresh, rad, sunh = S.layer(C / "fresh-air.geojson"), S.layer(C / "radiation.geojson"), S.layer(C / "sun-hours.geojson")
    rules = S.layer(C / "rules.geojson")
    if fresh or rad or sunh:
        m = Map(S, st, ext, scale, "Open space and climate", "Cold air kept open, shade where it is hot, play in the sun")
        m.context()
        hot = None
        if rad or sunh:
            L_ = rad or sunh
            key = "kwh_min" if rad else "hours_min"
            vals = sorted({p.get(key, 0) for _, p in L_})
            cut = vals[int(len(vals) * 2 / 3)] if len(vals) > 2 else vals[-1]
            hot = polys(union([g for g, p in L_ if p.get(key, 0) >= cut]).intersection(ext))
            hf = m.dots("hot", mix(st["context"], ink, 0.35), 1.2, 0.13)
            m.add(hot, fill=hf, stroke="none")
            m.key("fill", hf, f"Hot open ground today: {'radiation' if rad else 'sun hours'} in the top third", stroke=st["context"])
        noise = union([g for g, p in rules if p.get("kind") == "dont" and p.get("topic") == "noise" and g.geom_type.endswith("Polygon")])
        if not noise.is_empty:
            nf = m.hatch("noise", mix(paper, ink, 0.45), 1.0, -45, st["thin"] * 1.2)
            m.add(noise, fill=nf, stroke="none")
            m.key("fill", nf, "Too loud for play (climate rules)", stroke=st["context"])
        corr = union([g for g, p in fresh if p.get("kind") == "corridor"])
        if not corr.is_empty:
            m.add(corr, fill="none", stroke=acc, stroke_width=st["thick"], stroke_dasharray="2 1")
            m.key("line", acc, "Cold-air corridor (climate)", dash="2 1", w=st["thick"])
        greens(m, legend=False)
        cf = m.hatch("conflict", ink, 1.1, 45, st["thin"])
        cf2 = m.hatch("conflict2", ink, 1.1, -45, st["thin"])
        for g, p in by("conflict"):
            m.add(g, fill=cf, stroke=ink, stroke_width=st["mid"])
            m.add(g, fill=cf2, stroke="none")
        for g, p in fresh:
            if p.get("kind") == "flow":
                m.add(g, fill="none", stroke=ink, stroke_width=st["mid"], marker_end="url(#arrow)")
        squares_play_trees(m, legend=False)
        m.site()
        m.key("fill", mix(paper, acc, 0.3), "Green and corridors of the proposal", stroke=acc)
        if by("conflict"):
            m.key("fill", cf, "Conflict: cold-air corridor on land planned for building; massing keeps it free or builds along the flow")
        if any(p.get("kind") == "flow" for _, p in fresh):
            m.key("arrow", ink, "Cold-air flow (climate)")
        m.key("dot", look_["tree"], "New tree: squares, hot routes and hot park edges, none in the corridor", r=1.1)
        m.key("fill", look_["play"], "Playground, placed at the sunniest spot in nearby green", stroke=paper)
        plays = by("playground")
        sun_ok = [p for _, p in plays if (p.get("sun_share") or 0) >= 0.75]
        m.facts = [f"Trees in hot areas: {sum(1 for g, p in by('tree') if hot is not None and hot.contains(g))} of {K['trees_new']}",
                   f"Playgrounds in full sun: {len(sun_ok)} of {len(plays)}"]
        if K.get("cold_air_conflicts"):
            m.facts.append("Corridor on building land: " + ", ".join(f"{c['name']} {c['ha']} ha" for c in K["cold_air_conflicts"]))
        csrc = []
        for f in ("fresh-air", "sun"):
            if (C / f"{f}.json").exists():
                csrc += read(C / f"{f}.json").get("sources", [])[:1]
        made.append(m.save(out / "climate-fit.svg", base_src + csrc))
    (out / "drawings.txt").write_text(f"Scale 1:{scale}. {look}.\n" + "\n".join(f"{n} (PNG: {h or 'none, no browser'})" for n, h in made) + "\n", encoding="utf-8")
    print(f"1:{scale}", look, made)


if __name__ == "__main__":
    main()
